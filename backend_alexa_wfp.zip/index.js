let welcomeOutput = "Welcome to the World Food Programme dashboard ! What would you like to know about W F P ?";
let welcomeReprompt = "You can ask a question like how many outputs WFP serves in Nepal ?";
let speechOutput;
let reprompt;

'use strict';
const Alexa = require('alexa-sdk');

const handlers = {
    'LaunchRequest': function () {
        //This is triggered when the user says: 'Open wfp asia pacific'
        this.emit(':ask', welcomeOutput, welcomeReprompt)
    },
    'GetIndicatorCountry': function () {
        //This is triggered when the user says: 'tell me how many {indicator} has in {wfpcountry}?'

        const fs = require('fs');
        let rawdata = fs.readFileSync('data.json');
        let content = JSON.parse(rawdata);
		let indicatorSlotRaw = this.event.request.intent.slots.indicator.value;
		let wfpcountrySlotRaw = this.event.request.intent.slots.wfpcountry.value;
		if (!content.hasOwnProperty(indicatorSlotRaw)){
		    speechOutput = 'This indicator is not availale yet';
		    this.emit(":ask", speechOutput);
		}
		else if (!content[indicatorSlotRaw].hasOwnProperty(wfpcountrySlotRaw)){
		    speechOutput = 'The country is not yet part of WFP';
		    this.emit(":ask", speechOutput);
		}
		else {
		    speechOutput = 'There is ' + content[indicatorSlotRaw][wfpcountrySlotRaw]  + indicatorSlotRaw  + ' in ' + wfpcountrySlotRaw;
            this.emit(":ask", speechOutput);
		}
    },
    'GetNonCompliantIntent': function () {
            speechOutput = 'Don\'t push your luck. For this type of information WFP will need to upgrade its system';
            this.emit(":ask", speechOutput);
    },
    'AMAZON.HelpIntent': function () {
        //This is triggered when the user says: 'Help'
        speechOutput = '';
        this.emit(':tell', speechOutput);

    },
    'AMAZON.CancelIntent': function () {
        //This is triggered when the user says: 'Cancel'
        speechOutput = '';
        this.emit(':tell', speechOutput);
    },
    'AMAZON.StopIntent': function () {
        //This is triggered when the user says: 'Stop'
        speechOutput = '';
        this.emit(':tell', speechOutput);
    },
};

exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.registerHandlers(handlers);
    alexa.execute();
};
